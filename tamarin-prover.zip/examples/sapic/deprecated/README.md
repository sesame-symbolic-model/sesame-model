The following case studies make use of the accountability implementation of the now deprecated [SAPiC plugin](https://github.com/tamarin-prover/tamarin-prover/tree/develop/plugins/sapic):

- (./accountability-old): See (./accountability-old/README.md).
- (./csf21-acc-unbounded): See (./csf21-acc-unbounded/README.md).
