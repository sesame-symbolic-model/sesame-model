The following case studies are in the repository, but cannot be proven automatically:

- (./PKCS11/pkcs11-dynamic-policy.spthy): This model is not working.
- (./envelope): These examples were never completed and are here for reference only.
