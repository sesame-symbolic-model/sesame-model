# Tamarin design

## Emperor Tamarin pixel art 

The source file is `tamarin-pixelart-16.kra` which was created using
`krita`.

This can be used to export a 16x16 png file, which can be upscaled (no
smoothing) to the 32x32 and 64x64 versions.

The source file was also used as the basis for
`tamarin-pixelart-large_grid.xcf` and
`tamarin-pixelart-large_grid_details.xcf`. Both files are 420x420
pixels, and are intended for the `gimp` editor.  The second file has
more subtle shading and highlights.




